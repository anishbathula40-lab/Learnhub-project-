import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { BookOpen, Search, Menu, X, ArrowRight, Clock3, Users, Star, GraduationCap, LayoutDashboard, LogOut, PlayCircle, CheckCircle2, Sparkles, Code2, BarChart3, Palette, BriefcaseBusiness, Globe, ChevronRight, LockKeyhole, Mail, UserRound, Plus, Check } from 'lucide-react'
import './styles.css'

const COURSES = [
  { id: 'python', title: 'Python Programming: From Zero to Hero', category: 'Development', level: 'Beginner', duration: '6 weeks', lessons: 18, rating: '4.9', students: 1240, color: 'violet', icon: 'code', description: 'Build a strong foundation in Python with practical exercises, core concepts, and mini projects.', instructor: 'Alex Morgan', topics: ['Variables and data types', 'Conditions and loops', 'Functions', 'Lists and dictionaries', 'Mini project'] },
  { id: 'data', title: 'Data Science Fundamentals', category: 'Data Science', level: 'Beginner', duration: '8 weeks', lessons: 24, rating: '4.8', students: 980, color: 'blue', icon: 'chart', description: 'Learn how to explore, analyze, and communicate insights from real-world datasets.', instructor: 'Priya Sharma', topics: ['Data analysis workflow', 'NumPy basics', 'Pandas data frames', 'Visualization', 'Capstone project'] },
  { id: 'web', title: 'Modern Web Development', category: 'Development', level: 'Intermediate', duration: '7 weeks', lessons: 21, rating: '4.9', students: 1560, color: 'orange', icon: 'globe', description: 'Understand the building blocks of modern websites and create a responsive portfolio.', instructor: 'Jordan Lee', topics: ['HTML and semantics', 'CSS layouts', 'JavaScript fundamentals', 'Responsive design', 'Portfolio project'] },
  { id: 'design', title: 'UI/UX Design Essentials', category: 'Design', level: 'Beginner', duration: '4 weeks', lessons: 14, rating: '4.7', students: 740, color: 'pink', icon: 'palette', description: 'Explore user research, wireframes, visual hierarchy, and accessible interface design.', instructor: 'Mia Chen', topics: ['Design principles', 'User personas', 'Wireframing', 'Prototyping', 'Usability testing'] },
  { id: 'business', title: 'Project Management Basics', category: 'Business', level: 'Beginner', duration: '5 weeks', lessons: 16, rating: '4.8', students: 610, color: 'green', icon: 'business', description: 'Plan projects, communicate with teams, and manage scope, risks, and timelines.', instructor: 'Sam Rivera', topics: ['Project lifecycle', 'Planning and scope', 'Risk management', 'Team communication', 'Retrospectives'] },
  { id: 'sql', title: 'SQL & Database Foundations', category: 'Data Science', level: 'Beginner', duration: '3 weeks', lessons: 12, rating: '4.8', students: 890, color: 'cyan', icon: 'code', description: 'Query relational data confidently using filtering, joins, grouping, and subqueries.', instructor: 'Taylor Brooks', topics: ['Tables and keys', 'SELECT queries', 'Joins', 'Aggregations', 'Practice database'] },
]
const CATEGORIES = [
  { name: 'Development', icon: Code2, count: '2 courses' },
  { name: 'Data Science', icon: BarChart3, count: '2 courses' },
  { name: 'Design', icon: Palette, count: '1 course' },
  { name: 'Business', icon: BriefcaseBusiness, count: '1 course' },
]
const initialUser = () => { try { return JSON.parse(localStorage.getItem('learnhub_user')) } catch { return null } }
const initialEnrollments = () => { try { return JSON.parse(localStorage.getItem('learnhub_enrollments') || '{}') } catch { return {} } }
const iconFor = (name) => ({ code: Code2, chart: BarChart3, globe: Globe, palette: Palette, business: BriefcaseBusiness }[name] || BookOpen)

function App() {
  const [user, setUser] = useState(initialUser)
  const [enrollments, setEnrollments] = useState(initialEnrollments)
  const [page, setPage] = useState('home')
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All')
  const [selected, setSelected] = useState(null)
  const [authMode, setAuthMode] = useState('login')
  const [authOpen, setAuthOpen] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [notice, setNotice] = useState('')
  const [authForm, setAuthForm] = useState({ name: '', email: '', password: '' })

  useEffect(() => { localStorage.setItem('learnhub_enrollments', JSON.stringify(enrollments)) }, [enrollments])
  useEffect(() => { if (user) localStorage.setItem('learnhub_user', JSON.stringify(user)); else localStorage.removeItem('learnhub_user') }, [user])
  useEffect(() => { if (!notice) return; const t = setTimeout(() => setNotice(''), 3000); return () => clearTimeout(t) }, [notice])

  const myEnrollments = user ? (enrollments[user.email] || {}) : {}
  const enrolledCourses = COURSES.filter(c => myEnrollments[c.id])
  const visibleCourses = useMemo(() => COURSES.filter(c => (category === 'All' || c.category === category) && `${c.title} ${c.category} ${c.description}`.toLowerCase().includes(search.toLowerCase())), [category, search])

  function go(next) { setPage(next); setMobileOpen(false); window.scrollTo({ top: 0, behavior: 'smooth' }) }
  function enroll(course) {
    if (!user) { setSelected(null); setAuthMode('login'); setAuthOpen(true); setNotice('Sign in to enroll and save your progress.'); return }
    setEnrollments(prev => {
      const current = prev[user.email] || {}
      if (current[course.id]) return prev
      return { ...prev, [user.email]: { ...current, [course.id]: { completed: [], enrolledAt: new Date().toISOString() } } }
    })
    setNotice(myEnrollments[course.id] ? 'You are already enrolled in this course.' : `Successfully enrolled in ${course.title}!`)
    setSelected(null)
    go('dashboard')
  }
  function toggleLesson(courseId, topic) {
    setEnrollments(prev => {
      const userCourses = { ...(prev[user.email] || {}) }
      const item = userCourses[courseId] || { completed: [] }
      const completed = item.completed.includes(topic) ? item.completed.filter(x => x !== topic) : [...item.completed, topic]
      userCourses[courseId] = { ...item, completed }
      return { ...prev, [user.email]: userCourses }
    })
  }
  function submitAuth(e) {
    e.preventDefault()
    const email = authForm.email.trim().toLowerCase()
    if (!email || !authForm.password) { setNotice('Enter your email and password.'); return }
    if (authMode === 'signup' && !authForm.name.trim()) { setNotice('Enter your name to create an account.'); return }
    // Demo-only client-side auth: replace with a real authentication provider for production.
    const nextUser = { name: authMode === 'signup' ? authForm.name.trim() : (email.split('@')[0].replace(/[._-]/g, ' ') || 'Student'), email }
    setUser(nextUser); setAuthOpen(false); setAuthForm({ name: '', email: '', password: '' }); setNotice(`Welcome${nextUser.name ? ', ' + nextUser.name : ''}!`)
    go('dashboard')
  }
  function logout() { setUser(null); setPage('home'); setNotice('You have signed out.') }

  return <div className="app">
    <header className="header">
      <div className="nav-wrap">
        <button className="brand" onClick={() => go('home')} aria-label="LearnHub home"><span className="brand-mark"><GraduationCap size={22}/></span><span>Learn<span className="brand-accent">Hub</span></span></button>
        <nav className={`nav-links ${mobileOpen ? 'open' : ''}`}>
          <button className={page === 'home' ? 'nav-active' : ''} onClick={() => go('home')}>Home</button>
          <button className={page === 'courses' ? 'nav-active' : ''} onClick={() => go('courses')}>Explore Courses</button>
          {user && <button className={page === 'dashboard' ? 'nav-active' : ''} onClick={() => go('dashboard')}>My Learning</button>}
          {mobileOpen && <button onClick={() => user ? logout() : (setAuthMode('login'), setAuthOpen(true))}>{user ? 'Sign out' : 'Sign in'}</button>}
        </nav>
        <div className="nav-actions">
          {user ? <><button className="user-pill" onClick={() => go('dashboard')}><span className="avatar">{user.name.slice(0,1).toUpperCase()}</span><span className="user-name">{user.name.split(' ')[0]}</span></button><button className="icon-button logout-button" title="Sign out" onClick={logout}><LogOut size={18}/></button></> : <><button className="login-button" onClick={() => { setAuthMode('login'); setAuthOpen(true) }}>Log in</button><button className="primary small" onClick={() => { setAuthMode('signup'); setAuthOpen(true) }}>Get started <ArrowRight size={16}/></button></>}
        </div>
        <button className="mobile-menu" onClick={() => setMobileOpen(v => !v)} aria-label="Toggle menu">{mobileOpen ? <X/> : <Menu/>}</button>
      </div>
    </header>

    {page === 'home' && <main>
      <section className="hero">
        <div className="hero-bg orb-one"></div><div className="hero-bg orb-two"></div>
        <div className="hero-content">
          <div className="eyebrow"><Sparkles size={15}/> YOUR NEXT CHAPTER STARTS HERE</div>
          <h1>Learn something new.<br/><span>Change everything.</span></h1>
          <p className="hero-copy">Build skills that move you forward with practical courses taught by people who know their craft.</p>
          <div className="hero-search"><Search size={20}/><input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === 'Enter' && go('courses')} placeholder="What do you want to learn today?"/><button className="primary" onClick={() => go('courses')}>Find courses <ArrowRight size={17}/></button></div>
          <div className="hero-proof"><div className="avatar-stack"><span>J</span><span>M</span><span>A</span><span>S</span></div><div><strong>4,000+ learners</strong><small>are building skills with LearnHub</small></div><div className="proof-divider"></div><div className="rating"><Star size={16} fill="currentColor"/> <strong>4.8/5</strong><small> learner rating</small></div></div>
        </div>
        <div className="hero-visual" aria-label="Learning dashboard illustration"><div className="visual-window"><div className="window-top"><span></span><span></span><span></span><small>learning dashboard</small></div><div className="visual-inner"><div className="visual-welcome"><div><small>MONDAY, OCTOBER 13</small><h3>Keep growing, Alex ✨</h3><p>Your learning journey is looking good.</p></div><div className="visual-avatar">A</div></div><div className="visual-stats"><div><span className="stat-icon purple"><BookOpen size={17}/></span><b>04</b><small>Courses</small></div><div><span className="stat-icon mint"><CheckCircle2 size={17}/></span><b>12</b><small>Lessons done</small></div></div><div className="visual-course"><div className="mini-course-icon"><Code2 size={22}/></div><div className="mini-course-text"><b>Python Programming</b><small>Continue learning</small><div className="progress-track"><span style={{width:'68%'}}></span></div></div><b className="progress-number">68%</b></div><div className="visual-course"><div className="mini-course-icon blue"><BarChart3 size={22}/></div><div className="mini-course-text"><b>Data Science Basics</b><small>Keep your momentum</small><div className="progress-track"><span style={{width:'35%'}}></span></div></div><b className="progress-number">35%</b></div></div></div><div className="float-card float-top"><span className="float-icon"><Check size={17}/></span><div><b>Goal achieved!</b><small>You're on a 5-day streak</small></div></div><div className="float-card float-bottom"><span className="float-icon yellow"><Star size={17} fill="currentColor"/></span><div><b>New skill unlocked</b><small>Keep up the great work</small></div></div></div>
      </section>
      <section className="trust-strip"><span>LEARN AT YOUR OWN PACE</span><span><CheckCircle2 size={16}/> 100% free courses</span><span><PlayCircle size={16}/> Practical lessons</span><span><LayoutDashboard size={16}/> Track your progress</span></section>
      <section className="section categories-section"><div className="section-heading"><div><span className="section-kicker">FIND YOUR PATH</span><h2>Explore by category</h2><p>Start with what interests you. Grow into what inspires you.</p></div><button className="text-link" onClick={() => {setCategory('All'); go('courses')}}>All courses <ArrowRight size={17}/></button></div><div className="category-grid">{CATEGORIES.map(({name,icon:Icon,count},i)=><button className={`category-card category-${i}`} key={name} onClick={()=>{setCategory(name);go('courses')}}><span className="category-icon"><Icon size={23}/></span><span className="category-name">{name}</span><span className="category-count">{count}</span><ChevronRight className="category-arrow" size={19}/></button>)}</div></section>
      <section className="section featured-section"><div className="section-heading"><div><span className="section-kicker">CURATED FOR YOU</span><h2>Popular courses</h2><p>High-impact skills, practical projects, real progress.</p></div><button className="text-link" onClick={()=>go('courses')}>Browse all courses <ArrowRight size={17}/></button></div><div className="course-grid">{COURSES.slice(0,3).map(c=><CourseCard key={c.id} course={c} enrolled={!!myEnrollments[c.id]} onOpen={()=>setSelected(c)}/>)}</div></section>
      <section className="cta-section"><div className="cta-spark"><Sparkles size={24}/></div><div><h2>Your future self will thank you.</h2><p>Choose a course, learn a little every day, and see how far you can go.</p></div><button className="primary cta-button" onClick={()=>go('courses')}>Start learning for free <ArrowRight size={17}/></button></section>
    </main>}

    {page === 'courses' && <main className="page-main"><div className="page-title-row"><div><span className="section-kicker">THE COURSE CATALOG</span><h1>Find your next skill.</h1><p>Explore practical courses and learn at your own pace.</p></div><div className="catalog-count"><BookOpen size={18}/>{COURSES.length} courses available</div></div><div className="catalog-toolbar"><div className="catalog-search"><Search size={19}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search courses or skills..."/>{search && <button onClick={()=>setSearch('')}><X size={16}/></button>}</div><div className="filter-pills">{['All',...CATEGORIES.map(c=>c.name)].map(x=><button key={x} className={category===x?'filter-active':''} onClick={()=>setCategory(x)}>{x}</button>)}</div></div>{visibleCourses.length ? <div className="course-grid catalog-grid">{visibleCourses.map(c=><CourseCard key={c.id} course={c} enrolled={!!myEnrollments[c.id]} onOpen={()=>setSelected(c)}/>)}</div> : <div className="empty-state"><Search size={32}/><h3>No courses found</h3><p>Try another search or choose a different category.</p><button className="secondary" onClick={()=>{setSearch('');setCategory('All')}}>Clear filters</button></div>}</main>}

    {page === 'dashboard' && <main className="page-main dashboard-main"><div className="dashboard-welcome"><div><span className="section-kicker">YOUR LEARNING SPACE</span><h1>Welcome back{user ? `, ${user.name.split(' ')[0]}` : ''}.</h1><p>Every lesson is a step toward your next goal.</p></div>{!user && <button className="primary" onClick={()=>{setAuthMode('login');setAuthOpen(true)}}>Sign in to continue</button>}</div>{user ? <><div className="dashboard-stats"><div className="dash-stat"><span className="dash-stat-icon purple"><BookOpen/></span><div><strong>{enrolledCourses.length}</strong><small>Enrolled courses</small></div></div><div className="dash-stat"><span className="dash-stat-icon green"><CheckCircle2/></span><div><strong>{enrolledCourses.reduce((n,c)=>n+(myEnrollments[c.id]?.completed?.length||0),0)}</strong><small>Lessons completed</small></div></div><div className="dash-stat"><span className="dash-stat-icon orange"><GraduationCap/></span><div><strong>{enrolledCourses.filter(c=>(myEnrollments[c.id]?.completed?.length||0)>=c.topics.length).length}</strong><small>Courses completed</small></div></div></div><div className="section-heading dashboard-heading"><div><h2>My courses</h2><p>Pick up where you left off.</p></div><button className="text-link" onClick={()=>go('courses')}>Explore courses <ArrowRight size={17}/></button></div>{enrolledCourses.length ? <div className="my-course-list">{enrolledCourses.map(c=>{const done=myEnrollments[c.id]?.completed||[];const progress=Math.round(done.length/c.topics.length*100);const Icon=iconFor(c.icon);return <article className="my-course-card" key={c.id}><div className={`my-course-art art-${c.color}`}><Icon size={32}/></div><div className="my-course-body"><div className="my-course-top"><span className="course-category">{c.category}</span><span className="lesson-count">{done.length}/{c.topics.length} lessons</span></div><h3>{c.title}</h3><p>{c.instructor} · {c.duration}</p><div className="progress-row"><div className="progress-track"><span style={{width:`${progress}%`}}/></div><strong>{progress}%</strong></div><div className="lesson-checklist">{c.topics.map((topic,i)=><label key={topic} className={done.includes(topic)?'lesson-done':''}><input type="checkbox" checked={done.includes(topic)} onChange={()=>toggleLesson(c.id,topic)}/><span>{topic}</span>{done.includes(topic)&&<CheckCircle2 size={15}/>}</label>)}</div></div></article>})}</div> : <div className="empty-state"><span className="empty-illustration"><GraduationCap size={34}/></span><h3>Your learning journey starts here</h3><p>You haven't enrolled in a course yet. Browse the catalog and choose your first course.</p><button className="primary" onClick={()=>go('courses')}>Explore courses <ArrowRight size={17}/></button></div>}</> : <div className="empty-state"><LockKeyhole size={34}/><h3>Sign in to see your dashboard</h3><p>Your enrollments and lesson progress will appear here.</p><button className="primary" onClick={()=>{setAuthMode('login');setAuthOpen(true)}}>Log in</button></div>}</main>}

    <footer className="footer"><div className="footer-main"><div className="footer-brand"><button className="brand" onClick={()=>go('home')}><span className="brand-mark"><GraduationCap size={22}/></span><span>Learn<span className="brand-accent">Hub</span></span></button><p>Small steps. Big possibilities.<br/>Learning that moves you forward.</p></div><div className="footer-column"><b>Explore</b><button onClick={()=>go('courses')}>All courses</button><button onClick={()=>{setCategory('Development');go('courses')}}>Development</button><button onClick={()=>{setCategory('Data Science');go('courses')}}>Data Science</button></div><div className="footer-column"><b>Your account</b><button onClick={()=>user?go('dashboard'):(setAuthMode('login'),setAuthOpen(true))}>My learning</button><button onClick={()=>{setAuthMode('signup');setAuthOpen(true)}}>Create account</button><button onClick={()=>{setAuthMode('login');setAuthOpen(true)}}>Sign in</button></div><div className="footer-note"><span className="footer-note-icon"><Sparkles size={20}/></span><b>Learning should be for everyone.</b><p>Explore every course for free and learn at your own pace.</p></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} LearnHub. Course Enrollment Project.</span><span>Made for curious minds <span className="heart">♥</span></span></div></footer>

    {selected && <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&setSelected(null)}><div className="course-modal"><button className="modal-close" onClick={()=>setSelected(null)} aria-label="Close"><X/></button><div className={`modal-art art-${selected.color}`}>{React.createElement(iconFor(selected.icon),{size:38})}<span>LEARNHUB COURSE</span></div><div className="modal-content"><span className="course-category">{selected.category} · {selected.level}</span><h2>{selected.title}</h2><p className="modal-description">{selected.description}</p><div className="modal-meta"><span><Clock3 size={16}/>{selected.duration}</span><span><PlayCircle size={16}/>{selected.lessons} lessons</span><span><Star size={16} fill="currentColor"/>{selected.rating}</span></div><h3>What you'll learn</h3><ul className="topic-list">{selected.topics.map(t=><li key={t}><CheckCircle2 size={17}/>{t}</li>)}</ul><div className="modal-bottom"><div><strong>Free</strong><small>Full course access</small></div><button className="primary" onClick={()=>enroll(selected)}>{myEnrollments[selected.id]?'Continue learning':'Enroll for free'} <ArrowRight size={17}/></button></div></div></div></div>}

    {authOpen && <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&setAuthOpen(false)}><div className="auth-modal"><button className="modal-close" onClick={()=>setAuthOpen(false)} aria-label="Close"><X/></button><div className="auth-side"><span className="auth-logo"><GraduationCap size={30}/></span><span className="section-kicker">WELCOME TO LEARNHUB</span><h2>Make room for<br/>what's next.</h2><p>Learn practical skills, track your progress, and celebrate every milestone.</p><div className="auth-side-bottom"><CheckCircle2 size={17}/> Free courses. Your pace. Your future.</div></div><div className="auth-form-wrap"><div className="auth-tabs"><button className={authMode==='login'?'auth-tab-active':''} onClick={()=>setAuthMode('login')}>Log in</button><button className={authMode==='signup'?'auth-tab-active':''} onClick={()=>setAuthMode('signup')}>Create account</button></div><h2>{authMode==='login'?'Welcome back':'Get started for free'}</h2><p className="auth-subtitle">{authMode==='login'?'Enter your details to continue learning.':'Create an account to save your learning progress.'}</p><form onSubmit={submitAuth}>{authMode==='signup'&&<label className="field-label">Full name<div className="input-wrap"><UserRound size={18}/><input value={authForm.name} onChange={e=>setAuthForm({...authForm,name:e.target.value})} placeholder="Your name" required/></div></label>}<label className="field-label">Email address<div className="input-wrap"><Mail size={18}/><input type="email" value={authForm.email} onChange={e=>setAuthForm({...authForm,email:e.target.value})} placeholder="you@example.com" required/></div></label><label className="field-label">Password<div className="input-wrap"><LockKeyhole size={18}/><input type="password" value={authForm.password} onChange={e=>setAuthForm({...authForm,password:e.target.value})} placeholder="Enter password" minLength={4} required/></div></label><button className="primary auth-submit" type="submit">{authMode==='login'?'Log in':'Create account'} <ArrowRight size={17}/></button></form><p className="demo-note"><LockKeyhole size={14}/> Demo authentication only — do not use a real password.</p><p className="auth-switch">{authMode==='login'?"New to LearnHub?":"Already have an account?"} <button onClick={()=>setAuthMode(authMode==='login'?'signup':'login')}>{authMode==='login'?'Create account':'Log in'}</button></p></div></div></div>}
    {notice && <div className="toast"><CheckCircle2 size={18}/>{notice}<button onClick={()=>setNotice('')}><X size={15}/></button></div>}
  </div>
}

function CourseCard({course:c,enrolled,onOpen}) {
  const Icon=iconFor(c.icon)
  return <article className="course-card"><button className={`course-art art-${c.color}`} onClick={onOpen} aria-label={`View ${c.title}`}><span className="art-label">{c.category.toUpperCase()}</span><span className="art-shape shape-one"></span><span className="art-shape shape-two"></span><span className="art-icon"><Icon size={36}/></span><span className="art-level">{c.level}</span></button><div className="course-card-content"><div className="course-card-meta"><span className="course-category">{c.category}</span><span className="course-rating"><Star size={14} fill="currentColor"/>{c.rating}</span></div><button className="course-title-button" onClick={onOpen}><h3>{c.title}</h3></button><p className="course-description">{c.description}</p><div className="course-instructor"><span className="instructor-avatar">{c.instructor.split(' ').map(n=>n[0]).join('')}</span><span>{c.instructor}</span></div><div className="course-card-bottom"><span><Clock3 size={15}/>{c.duration}</span><span><PlayCircle size={15}/>{c.lessons} lessons</span></div><div className="course-card-action"><span className="free-label">FREE</span><button onClick={onOpen}>{enrolled?'Continue':'View course'} <ArrowRight size={15}/></button></div></div></article>
}

createRoot(document.getElementById('root')).render(<App/>)
